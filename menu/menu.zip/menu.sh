#!/bin/bash
# COLOR VALIDATION
clear
y='\033[1;33m' #yellow
BGX="\033[42m"
CYAN="\033[96m"
z="\033[0;33m"
f="\033[1;97;41m"
RED='\033[0;31m'
NC='\033[0m'
gray="\e[1;30m"
Blue="\033[0;34m"
green='\033[0;32m'
grenbo="\e[92;1m"
purple="\033[1;95m"
YELL='\033[0;33m'
#INTALLER-UDP
UDPX="https://docs.google.com/uc?export=download&confirm=$(wget --quiet --save-cookies /tmp/cookies.txt --keep-session-cookies --no-check-certificate 'https://docs.google.com/uc?export=download&id=1S3IE25v_fyUfCLslnujFBSBMNunDHDk2' -O- | sed -rn 's/.*confirm=([0-9A-Za-z_]+).*/\1\n/p')&id=1S3IE25v_fyUfCLslnujFBSBMNunDHDk2"
ISP=$(cat /root/.info/.isp)
CITY=$(cat /root/.info/.city)
IPVPS=$(curl -s ipv4.icanhazip.com)
NS=$(cat /etc/xray/dns)
domain=$(cat /etc/xray/domain)
RAM=$(free -m | awk 'NR==2 {print $2}')
USAGERAM=$(free -m | awk 'NR==2 {print $3}')
MEMOFREE=$(printf '%-1s' "$(free -m | awk 'NR==2{printf "%.2f%%", $3*100/$2 }')")
LOADCPU=$(printf '%-0.00001s' "$(top -bn1 | awk '/Cpu/ { cpu = "" 100 - $8 "%" }; END { print cpu }')")
MODEL=$(cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/"//g' | sed 's/PRETTY_NAME//g')
CORE=$(printf '%-1s' "$(grep -c cpu[0-9] /proc/stat)")
DATEVPS=$(date +'%d-%m-%Y')
TIMEZONE=$(printf '%(%H-%M-%S)T')
SERONLINE=$(uptime -p | cut -d " " -f 2-10000)
clear
MYIP=$(curl -sS ipv4.icanhazip.com)
echo ""
izinsc="https://raw.githubusercontent.com/Scm88vpn/permision/main/reg"
# USERNAME
rm -f /usr/bin/user
username=$(curl ${izinsc} | grep $MYIP | awk '{print $2}')
echo "$username" >/usr/bin/user
# validity
rm -f /usr/bin/e
valid=$(curl ${izinsc} | grep $MYIP | awk '{print $3}')
echo "$valid" >/usr/bin/e
# DETAIL ORDER
username=$(cat /usr/bin/user)
oid=$(cat /usr/bin/ver)
exp=$(cat /usr/bin/e)
clear
# CERTIFICATE STATUS
d1=$(date -d "$valid" +%s)
d2=$(date -d "$today" +%s)
certifacate=$(((d1 - d2) / 86400))
# VPS Information
DATE=$(date +'%Y-%m-%d')
datediff() {
    d1=$(date -d "$1" +%s)
    d2=$(date -d "$2" +%s)
    echo -e "$COLOR1 $NC Expiry In   : $(( (d1 - d2) / 86400 )) Days"
}
mai="datediff "$Exp" "$DATE""

# Status Expired Or Active
Info="(${green}Active${NC})"
Error="(${RED}Expired${NC})"
today=`date -d "0 days" +"%Y-%m-%d"`
Exp1=$(curl ${izinsc} | grep $MYIP | awk '{print $3}')
if [[ $today < $Exp1 ]]; then
sts="${Info}"
else
sts="${Error}"
fi
#Download/Upload today
dtoday="$(vnstat -i eth0 | grep "today" | awk '{print $2" "substr ($3, 1, 1)}')"
utoday="$(vnstat -i eth0 | grep "today" | awk '{print $5" "substr ($6, 1, 1)}')"
ttoday="$(vnstat -i eth0 | grep "today" | awk '{print $8" "substr ($9, 1, 1)}')"
#Download/Upload yesterday
dyest="$(vnstat -i eth0 | grep "yesterday" | awk '{print $2" "substr ($3, 1, 1)}')"
uyest="$(vnstat -i eth0 | grep "yesterday" | awk '{print $5" "substr ($6, 1, 1)}')"
tyest="$(vnstat -i eth0 | grep "yesterday" | awk '{print $8" "substr ($9, 1, 1)}')"
#Download/Upload current month
dmon="$(vnstat -i eth0 -m | grep "`date +"%b '%y"`" | awk '{print $3" "substr ($4, 1, 1)}')"
umon="$(vnstat -i eth0 -m | grep "`date +"%b '%y"`" | awk '{print $6" "substr ($7, 1, 1)}')"
tmon="$(vnstat -i eth0 -m | grep "`date +"%b '%y"`" | awk '{print $9" "substr ($10, 1, 1)}')"
clear
# OS Uptime
uptime="$(uptime -p | cut -d " " -f 2-10)"

# Getting CPU Information
cpu_usage1="$(ps aux | awk 'BEGIN {sum=0} {sum+=$3}; END {print sum}')"
cpu_usage="$((${cpu_usage1/\.*} / ${coREDiilik:-1}))"
cpu_usage+=" %"

WKT=$(curl -s ipinfo.io/timezone )
DAY=$(date +%A)
DATE=$(date +%m/%d/%Y)
DATE2=$(date -R | cut -d " " -f -5)
IPVPS=$(curl -s ipv4.icanhazip.com)
cname=$( awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo )
cores=$( awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo )
freq=$( awk -F: ' /cpu MHz/ {freq=$2} END {print freq}' /proc/cpuinfo )
tram=$( free -m | awk 'NR==2 {print $2}' )
uram=$( free -m | awk 'NR==2 {print $3}' )
fram=$( free -m | awk 'NR==2 {print $4}' )
clear
ssh_service=$(/etc/init.d/ssh status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
dropbear_service=$(/etc/init.d/dropbear status | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
haproxy_service=$(systemctl status haproxy | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
xray_service=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
nginx_service=$(systemctl status nginx | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
#Status | Geo Project
clear
# STATUS SERVICE  SSH 
if [[ $ssh_service == "running" ]]; then 
   status_ssh="${green} ☑️ ${NC}"
else
   status_ssh="${RED} 🔴 ${NC} "
fi

# // SSH Websocket Proxy
ssh_ws=$( systemctl status ws | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g' )
if [[ $ssh_ws == "running" ]]; then
    status_ws_epro="${green} ☑️ ${NC}"
else
    status_ws_epro="${RED} 🔴 ${NC} "
fi

# STATUS SERVICE HAPROXY
if [[ $haproxy_service == "running" ]]; then 
   status_haproxy="${green} ☑️ ${NC}"
else
   status_haproxy="${RED} 🔴 ${NC} "
fi

# STATUS SERVICE XRAY
if [[ $xray_service == "running" ]]; then 
   status_xray="${green} ☑️ ${NC}"
else
   status_xray="${RED} 🔴 ${NC} "
fi

# STATUS SERVICE NGINX
if [[ $nginx_service == "running" ]]; then 
   status_nginx="${green} ☑️ ${NC}"
else
   status_nginx="${RED} 🔴 ${NC} "
fi

# STATUS SERVICE Dropbear
if [[ $dropbear_service == "running" ]]; then 
   status_dropbear="${green} ☑️ ${NC}"
else
   status_dropbear="${RED} 🔴 ${NC} "
fi
#####INFOAKUN
vlx=$(grep -c -E "^#& " "/etc/xray/config.json")
let vla=$vlx/2
vmc=$(grep -c -E "^### " "/etc/xray/config.json")
let vma=$vmc/2
ssh1="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
trx=$(grep -c -E "^#! " "/etc/xray/config.json")
let trb=$trx/2
ssx=$(grep -c -E "^#ss# " "/etc/xray/config.json")
let ssa=$ssx/2
#noobzvpns=$(grep -c -E "^#& " "/etc/noobzvpns/config.json")
###########
KANAN="\033[1;32m<\033[1;33m<\033[1;31m<\033[1;31m$NC"
KIRI="\033[1;32m>\033[1;33m>\033[1;31m>\033[1;31m$NC"
########
r="\033[1;31m"  #REDTERANG
a=" ${CYAN}ACCOUNT PREMIUM" 
#clear
echo -e " "
echo -e " ${z}╭══════════════════════════════════════════════════════════╮${NC}"
echo -e " ${z}│$NC${f}                   SCM VVIP TUNNELING                    $NC${z}│$NC"
echo -e " ${z}╰══════════════════════════════════════════════════════════╯${NC}"
echo -e " ${z}══════════════════════════════════════════════════════════${NC}"
echo -e " ${z}$NC$r 🧿 $NC$y System OS ${NC}     $Blue=$NC $MODEL${NC}"
echo -e " ${z}$NC$r 🧿 $NC$y ISP ${NC}           $Blue=$NC $ISP${NC}"
echo -e " ${z}$NC$r 🧿 $NC$y CITY ${NC}          $Blue=$NC $CITY${NC}"
echo -e " ${z}$NC$r 🧿 $NC$y Server RAM ${NC}    $Blue=$NC $tram MB $NC"
echo -e " ${z}$NC$r 🧿 $NC$y Core Cpu ${NC}      $Blue=$NC $CORE${NC}" CPU
echo -e " ${z}$NC$r 🧿 $NC$y Uptime Server ${NC} $Blue=$NC $SERONLINE${NC}"
echo -e " ${z}$NC$r 🧿 $NC$y Date ${NC}          $Blue=$NC $DATEVPS${NC}"
echo -e " ${z}$NC$r 🧿 $NC$y Cpu Usage ${NC}     $Blue=$NC $cpu_usage${NC}"
#echo -e " ${z}$NC 🧿 $NC$y Cpu Usage ${NC}.      $Blue=$NC $cpu_usage${NC}"
echo -e " ${z}$NC$r 🧿 $NC$y Domain ${NC}        $Blue=$NC $domain${NC}"
echo -e " ${z}══════════════════════════════════════════════════════════${NC}"
echo -e "            ${KIRI} ${Blue}INFORMATION ACCOUNT ON VPS${NC} ${KANAN}"
echo -e "          ${z}┌─────────────────────────────────────┐${NC}" | lolcat
echo -e "                 ${CYAN}ACCOUNT SSH/OVPN/UDP${NC}   $y=$NC $ssh1${NC}"
echo -e "                 ${CYAN}ACCOUNT VMESS/WS/GRPC${NC}  $y=$NC $vma$NC"
echo -e "                 ${CYAN}ACCOUNT VLESS/WS/GRPC${NC}  $y=$NC $vla$NC" 
echo -e "                 ${CYAN}ACCOUNT TROJAN/WS/GRPC${NC} $y=$NC $trb${NC}"
echo -e "                 ${CYAN}ACCOUNT SHADOW/WS/GRPC${NC} $y=$NC $ssa${NC}"
#echo -e "                 ${CYAN}ACCOUNT NOOBZ VPN${NC}      $y=$NC $nob$NC"
echo -e "          ${z}└─────────────────────────────────────┘${NC}" | lolcat
echo -e "   $green 🧿 HARI INI : $NC $ttoday $green KEMARIN : $NC $tyest $green BULAN :$NC $tmon 🧿"
echo -e " ${z}╭════════════════╮╭══════════════════╮╭════════════════════╮${NC}"
echo -e " ${z}│ ${NC}$y SSH$NC : $status_ssh" "       $y NGINX$NC : $status_nginx" "       $y XRAY$NC : $status_xray     $NC${z}│$NC" 
echo -e " ${z}│ ${NC}$y WS-ePRO$NC : $status_ws_epro" "   $y DROPBEAR$NC : $status_dropbear" "    $y HAPROXY$NC : $status_haproxy  $NC${z}│$NC" 
echo -e " ${z}╰════════════════╯╰══════════════════╯╰════════════════════╯${NC}"
echo -e "            ${KIRI} ${Green} 🧿 ALL FITUR SC TUNNELING 🧿 ${NC} ${KANAN}"
echo -e "    ${z}══════════════════════════════════════════════════════${NC}" | lolcat
echo -e "           ${z}$NC [${r}01${NC}]$green MENU SSH$NC     ${z}│$NC [${r}06${NC}]$green MENU NOOBZVPN$NC ${z}$NC"
echo -e "           ${z}$NC [${r}02${NC}]$green MENU VMESS$NC   ${z}│$NC [${r}07${NC}]$green BCKUP/RSTR VIA BOT$NC ${z}$NC"
echo -e "           ${z}$NC [${r}03${NC}]$green MENU VLESS$NC   ${z}│$NC [${r}08${NC}]$green INSTALL UDP CUSTOM$NC ${z} $NC"
echo -e "           ${z}$NC [${r}04${NC}]$green MENU TROJAN$NC  ${z}│$NC [${r}09${NC}]$green BOT PANEL TELEGRAM$NC ${z} $NC"
echo -e "           ${z}$NC [${r}05${NC}]$green MENU SSWS$NC    ${z}│$NC [${r}10${NC}]$green MENU UTILITY$NC ${z} $NC"
echo -e "    ${z}══════════════════════════════════════════════════════${NC}" | lolcat
echo -e "            ${KIRI}${z} INFORMATION YOUR ACTIVE PERIOD ${z}${KANAN}"
echo -e " ${z}╭══════════════════════════════════════════════════════════╮${NC}"
echo -e " ${z}│$NC${z} Developer$NC  ${z}=$NC SCM VVIP TUNELL"
echo -e " ${z}│$NC${z} WA ADMIN$NC   ${z}=$NC 6283128222332"
echo -e " ${z}│$NC${z} IP ADDRESS ${z}=$NC $IPVPS${NC}"
echo -e " ${z}│$NC${z} User$NC       ${z}=$NC $username"
echo -e " ${z}│$NC${z} Exp Script$NC ${z}=$NC $exp $certifacate Days$NC $sts"
echo -e " ${z}╰══════════════════════════════════════════════════════════╯${NC}"
#echo -e "             ${KIRI}${z}DILARANG MERUBAH ISI SOURCE !${z}${KANAN}"
echo -e ""
read -p " SELECT OPTIONS ⟩ " opt
echo -e ""
case $opt in
1 | 01)
clear
m-sshws
;;
2 | 02)
clear
m-vmess
;;
3 | 03)
clear
m-vless
;;
4 | 04)
clear
m-trojan
;;
5 | 05)
clear
m-ssws
;;
6 | 06)
clear
m-noob
;;
7 | 07)
clear
mbot-backup
;;
8 | 08)
wget https://raw.githubusercontent.com/Scm88vpn/VVIP/main/udp-custom.sh && chmod +x udp-custom.sh && ./udp-custom.sh
;;
9 | 09)
clear
mbot-panel
;;
10)
clear
menu-x
;;
0 | 00)
exit
;;
x)
menu
;;
*) clear ;
echo -e 
menu
;;
esac